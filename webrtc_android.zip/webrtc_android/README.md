# WebRTC_XMPP

## 效果图

1.登录界面：
![这里写图片描述](http://img.blog.csdn.net/20160125201404382)

2.主界面(联系人列表界面)
![这里写图片描述](http://img.blog.csdn.net/20160125201515560)

3. 发送消息界面
![这里写图片描述](http://img.blog.csdn.net/20160125201538779)
