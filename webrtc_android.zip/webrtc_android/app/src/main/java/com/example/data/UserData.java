package com.example.data;


public class UserData {
    public String username; //用户名

    public UserData(String username) {
        this.username = username;
    }
}
