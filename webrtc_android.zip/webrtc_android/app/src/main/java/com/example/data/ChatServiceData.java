package com.example.data;

import org.jivesoftware.smackx.muc.HostedRoom;


public class ChatServiceData {
    public HostedRoom hostedRoom;
}
