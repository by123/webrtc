package com.example.data;



public class ChatData {
    public String user;         //  用于账号
    public String text;         //  聊天文本
    public boolean isOwner;     //  是否是当前登录用户
}
