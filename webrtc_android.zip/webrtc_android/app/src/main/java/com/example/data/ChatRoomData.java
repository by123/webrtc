package com.example.data;

import org.jivesoftware.smackx.disco.packet.DiscoverItems;


public class ChatRoomData {
    public DiscoverItems.Item item;
}
