package com.example.data;


public class LoginData {
    public static String userName;
    public static String passWord;

}
